﻿/*
 * GapJunction PLC-hez írt könyvtár
 * Törőcsik K. Konrád
 */

//#ifndef GapJunction_h
/*
 * GapJunction PLC-hez írt könyvtár
 * Törőcsik K. Konrád
 */

#include "Arduino.h"
#ifndef GapJunction_h
#define GapJunction_h

//class GapJunction
//{
  //public
 void GapJunctionSetup();  //kész
  void GapJunctionRun();    //kész
  void Relay(int x, int y);  //kész
  void Digital(int x, int y); //kész
  int Analog(int x); //kész
  void PWM(int x, int y); //kész
  
  int Input(int x); //kész
  void Text(int x, String y); //kész
  void ProgressText(String x); //kész
  void ProgressBar(int x); //kész
  void ProgramMode(int x, String y); //kész
  void Memory(String y); //kész
  extern int PressEvent;
  extern int Month;
  extern int Day;
  extern int Hour;
  extern int Minute;
  extern int Second;
  //private:
  void ManualData(); //kész
  void Temperature(); //kész
  static byte byteRead[6];
  static int Rstatus[7];
  static int Dstatus[7];
  static int Astatus[7];
  
  static bool GapJunctionBool;
//};


#endif