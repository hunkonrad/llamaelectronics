/*
 * GapJunction PLC-hez �rt k�nyvt�r
 * T�r�csik K. Konr�d
 */

 #include "Arduino.h"
 #include "GapJunction.h"

 #define low 0
 #define high 1
 #define relay 161
 #define relay1 1
 #define relay2 2
 #define relay3 3
 #define relay4 4
 #define relay5 5
 #define relay6 6
 #define digit 162
 #define digit1 1
 #define digit2 2
 #define digit3 3
 #define digit4 4
 #define digit5 5
 #define pwm 163
 #define pwm1 1
 #define pwm2 2
 #define pwm3 3
 #define pwm4 4
 #define pwm5 5
 #define rtcget 164
 #define pageget 165
 #define fooldal 0
 #define manualis 1
 #define automatikus 2

 int PressEvent;
 int Month;
 int Day;
 int Hour;
 int Minute;
 int Second;

void Relay(int x, int y)
{
  int r;
  switch (x)
  {
    case 1:
    r = 2;
    break;
    case 2:
    r = 4;
    break;
    case 3:
    r = 7;
    break;
    case 4:
    r = 8;
    break;
    case 5:
    r = 11;
    break;
    case 6:
    r = 12;
    break;
    default:
    Serial1.print("error.val+=1");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    break;
  }
  switch(y)
  {
    case 0:
    digitalWrite(r, LOW);
    break;
    case 1:
    digitalWrite(r, HIGH);
    break;
    default:
    Serial1.print("error.val+=1");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
  }
}

void Digital(int x, int y)
{
  int d;
  switch (x)
  {
    case 1:
    d = 3;
    break;
    case 2:
    d = 5;
    break;
    case 3:
    d = 6;
    break;
    case 4:
    d = 9;
    break;
    case 5:
    d = 10;
    break;
    default:
    Serial1.print("error.val+=1");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    break;
  }
  switch (y)
  {
    case 0:
    analogWrite(d, 0);
    break;
    case 1:
    analogWrite(d, 255);
    break;
    default:
    Serial1.print("error.val+=1");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    break;
  }
}

int Analog(int x)
{
  int a;
  switch(x)
  {
    case 1:
    a = analogRead(A0);
    break;
    case 2:
    a = analogRead(A1);
    break;
    case 3:
    a = analogRead(A2);
    break;
    case 4:
    a = analogRead(A3);
    break;
    case 5:
    a = analogRead(A6);
    break;
    default:
    a = 0;
    Serial1.print("error.val+=1");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    break;
  }
  return a;
}

void PWM(int x, int y)
{
  int d;
  int value;
  switch (x)
  {
    case 1:
    d = 3;
    break;
    case 2:
    d = 5;
    break;
    case 3:
    d = 6;
    break;
    case 4:
    d = 9;
    break;
    case 5:
    d = 10;
    break;
    default:
    Serial1.print("error.val+=1");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    break;
  }
  if(y<255)
  {
    analogWrite(d, y);
  }
  else
  {
    Serial1.print("error.val+=1");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
  }
}
void ManualData()
{
  int a1value = analogRead(A0);
  Serial1.print("va0.val=");
  Serial1.print(a1value);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  int a2value = analogRead(A1);
  Serial1.print("va1.val=");
  Serial1.print(a2value);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  int a3value = analogRead(A2);
  Serial1.print("va2.val=");
  Serial1.print(a3value);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  int a4value = analogRead(A3);
  Serial1.print("va3.val=");
  Serial1.print(a4value);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  int a5value = analogRead(A4);
  Serial1.print("va4.val=");
  Serial1.print(a5value);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  String r1status = "default";
  r1status = digitalRead(2);
  Serial1.print("va5.txt=\"");
  Serial1.print(r1status);
  Serial1.print("\"");
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
    String r2status = "default";
  r2status = digitalRead(4);
  Serial1.print("va6.txt=\"");
  Serial1.print(r2status);
  Serial1.print("\"");
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
      String r3status = "default";
  r3status = digitalRead(7);
  Serial1.print("va7.txt=\"");
  Serial1.print(r3status);
  Serial1.print("\"");
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
      String r4status = "default";
  r4status = digitalRead(8);
  Serial1.print("va8.txt=\"");
  Serial1.print(r4status);
  Serial1.print("\"");
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
      String r5status = "default";
  r5status = digitalRead(11);
  Serial1.print("va9.txt=\"");
  Serial1.print(r5status);
  Serial1.print("\"");
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
      String r6status = "default";
  r6status = digitalRead(12);
  Serial1.print("va10.txt=\"");
  Serial1.print(r6status);
  Serial1.print("\"");
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  int d1value = Dstatus[1];
  Serial1.print("va11.val=");
  Serial1.print(d1value);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  int d2value = Dstatus[2];
  Serial1.print("va12.val=");
  Serial1.print(d2value);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  int d3value = Dstatus[3];
  Serial1.print("va13.val=");
  Serial1.print(d3value);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  int d4value = Dstatus[4];
  Serial1.print("va14.val=");
  Serial1.print(d4value);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  int d5value = Dstatus[5];
  Serial1.print("va15.val=");
  Serial1.print(d5value);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
}

void Temperature()
{
  int temperature[3] = {0, 80, 75};
  temperature[0] = analogRead(A7);
if(temperature[0]>temperature[1])
{
  digitalWrite(13, HIGH);
}
else if(temperature[0]<temperature[2])
{
  digitalWrite(13, LOW);
}
  Serial1.print("temp.val=");
  Serial1.print(temperature[0]);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
}
 
 void GapJunctionSetup()
 {
  GapJunctionBool = true;
Serial1.begin(256000);
Serial1.setTimeout(100);
pinMode(2, OUTPUT);
pinMode(4, OUTPUT);
pinMode(7, OUTPUT);
pinMode(8, OUTPUT);
pinMode(11, OUTPUT);
pinMode(12, OUTPUT);
pinMode(13, OUTPUT);
pinMode(A0, INPUT);
pinMode(A1, INPUT);
pinMode(A2, INPUT);
pinMode(A3, INPUT);
pinMode(A6, INPUT);
pinMode(A7, INPUT);
analogWrite(3, 0);
analogWrite(5, 0);
analogWrite(6, 0);
analogWrite(9, 0);
analogWrite(10, 0);
digitalWrite(2, 0);
digitalWrite(4, 0);
digitalWrite(7, 0);
digitalWrite(8, 0);
digitalWrite(11, 0);
digitalWrite(12, 0);
while(Serial1.availableForWrite()<4) 
{ 
delay(10); 
}
  Serial1.print("rest");
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
}

void GapJunctionRun()
{

  do
  {

    

  if(Serial1.available()>0) 
  
{
  


 byteRead[0]=0;
 byteRead[1]=0;
 byteRead[2]=0;
 byteRead[3]=0;
 byteRead[4]=0;
 byteRead[5]=0;
 PressEvent=0;
    
    Serial1.readBytes(byteRead, 6);     //Update the byteRead variable with the Hex value received on the Serial1 COM port.

	

if(byteRead[0]==relay & byteRead[1]==relay1)
{
  Relay(1, byteRead[2]);
  Rstatus[1] = byteRead[2];
}
if(byteRead[0]==relay & byteRead[1]==relay2)
{
  Relay(2, byteRead[2]);
  Rstatus[2] = byteRead[2];
}
if(byteRead[0]==relay & byteRead[1]==relay3)
{
  Relay(3, byteRead[2]);
  Rstatus[3] = byteRead[2];
}
if(byteRead[0]==relay & byteRead[1]==relay4)
{
  Relay(4, byteRead[2]);
  Rstatus[4] = byteRead[2];
}
if(byteRead[0]==relay & byteRead[1]==relay5)
{
  Relay(5, byteRead[2]);
  Rstatus[5] = byteRead[2];
}
if(byteRead[0]==relay & byteRead[1]==relay6)
{
  Relay(6, byteRead[2]);
  Rstatus[6] = byteRead[2];
}
if(byteRead[0]==digit & byteRead[1]==digit1)
{
  Digital(1, byteRead[2]);
  Dstatus[1] = byteRead[2] * 255;
}
if(byteRead[0]==digit & byteRead[1]==digit2)
{
  Digital(2, byteRead[2]);
  Dstatus[2] = byteRead[2] * 255;
}
if(byteRead[0]==digit & byteRead[1]==digit3)
{
  Digital(3, byteRead[2]);
  Dstatus[3] = byteRead[2] * 255;
}
if(byteRead[0]==digit & byteRead[1]==digit4)
{
  Digital(4, byteRead[2]);
  Dstatus[4] = byteRead[2] * 255;
}
if(byteRead[0]==digit & byteRead[1]==digit5)
{
  Digital(5, byteRead[2]);
  Dstatus[5] = byteRead[2] * 255;
}
if(byteRead[0]==pwm & byteRead[1]==pwm1)
{
  PWM(1, byteRead[2]);
  Dstatus[1] = byteRead[2];
}
if(byteRead[0]==pwm & byteRead[1]==pwm2)
{
  PWM(2, byteRead[2]);
  Dstatus[2] = byteRead[2];
}
if(byteRead[0]==pwm & byteRead[1]==pwm3)
{
  PWM(2, byteRead[2]);
  Dstatus[3] = byteRead[2];
}
if(byteRead[0]==pwm & byteRead[1]==pwm4)
{
  PWM(3, byteRead[2]);
  Dstatus[4] = byteRead[2];
}
if(byteRead[0]==pwm & byteRead[1]==pwm5)
{
  PWM(5, byteRead[2]);
  Dstatus[5] = byteRead[2];
}

if(byteRead[0]==rtcget)
{
  Month = byteRead[1];
  Day = byteRead[2];
  Hour = byteRead[3];
  Minute = byteRead[4];
  Second = byteRead[5];
  Temperature();
}
if(byteRead[0]==pageget & byteRead[1]==manualis)
{
  ManualData();
  GapJunctionBool = true;
}
if(byteRead[0]==pageget & byteRead[1]==automatikus)
{
  GapJunctionBool = false;
  PressEvent = byteRead[2];
}
if(byteRead[0]==pageget & byteRead[1]==fooldal)
{
  GapJunctionBool = true;
}
}

  }while(GapJunctionBool==true);
  
}



int Input(int x)
{
  int a;
  switch(x)
  {
    case 1:
    a = analogRead(A0);
    break;
    case 2:
    a = analogRead(A1);
    break;
    case 3:
    a = analogRead(A2);
    break;
    case 4:
    a = analogRead(A3);
    break;
    case 5:
    a = analogRead(A6);
    break;
    default:
    a = 0;
    Serial1.print("error.val+=1");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    break;
  }
  if(a > 200)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

void Text(int x, String y)
{
  Serial1.print("text");
  Serial1.print(x);
  Serial1.print(".txt=\"");
  Serial1.print(y);
  Serial1.print("\"");
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
}

void Progresstext(String x)
{
  Serial1.print("progresstext.txt\"");
  Serial1.print(x);
  Serial1.print("\"");
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
}

void ProgressBar(int x)
{
  if(x < 101)
  {
  Serial1.print("progress.val=");
  Serial1.print(x);
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  }
  else
  {
    Serial1.print("Invalid value");
  }
  }

  void ProgramMode(int x, String y)
{
  if(x < 7)
  {
  Serial1.print("program");
  Serial1.print(x);
  Serial1.print(".txt=\"");
  Serial1.print(y);
  Serial1.print("\"");
  Serial1.write(0xff);
  Serial1.write(0xff);
  Serial1.write(0xff);
  }
  else
  {
    Serial1.print("Invalid value");
  }
}

void Memory(String y)
{
  //byte value[1000];
  //switch (x)
  //{
    //case 0:
    //if(Serial1.available()>0)
    //{
    //Serial1.readBytes(value, 1000);
    //String result = String((char*)value);
	//Serial1.println(result);
    //Serial1.write(0xff);
    //Serial1.write(0xff);
    //Serial1.write(0xff);
    //}
    //break;
    //case 1:
    Serial1.print("wepo rtcmonth.txt,sys2");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.print("sys2+=2");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.print("wepo rtcday.txt,sys2");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.print("sys2+=2");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.print("wepo rtchour.txt,sys2");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.print("sys2+=2");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.print("wepo rtcminute.txt,sys2");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.print("sys2+=2");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.print("wepo \"");
    Serial1.print(y);
    Serial1.print("\",sys2");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.print("sys2+=8");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.print("wepo sys2,1000");
    Serial1.write(0xff);
    Serial1.write(0xff);
    Serial1.write(0xff);
    //break;
    //default:
    //Serial1.print("error.val+=1");
    //Serial1.write(0xff);
    //Serial1.write(0xff);
    //Serial1.write(0xff);
    //break;
  //}
}
