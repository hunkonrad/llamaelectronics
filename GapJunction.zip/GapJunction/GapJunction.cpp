﻿/*
 * GapJunction PLC-hez írt könyvtár
 * Törőcsik K. Konrád
 */

 #include "Arduino.h"
 #include "GapJunction.h"

 #define low 0
 #define high 1
 #define relay 161
 #define relay1 1
 #define relay2 2
 #define relay3 3
 #define relay4 4
 #define relay5 5
 #define relay6 6
 #define digit 162
 #define digit1 1
 #define digit2 2
 #define digit3 3
 #define digit4 4
 #define digit5 5
 #define pwm 163
 #define pwm1 1
 #define pwm2 2
 #define pwm3 3
 #define pwm4 4
 #define pwm5 5
 #define rtcget 164
 #define pageget 165
 #define fooldal 0
 #define manualis 1
 #define automatikus 2

 int PressEvent;
 int Month;
 int Day;
 int Hour;
 int Minute;
 int Second;

void Relay(int x, int y)
{
  int r;
  switch (x)
  {
    case 1:
    r = 2;
    break;
    case 2:
    r = 4;
    break;
    case 3:
    r = 7;
    break;
    case 4:
    r = 8;
    break;
    case 5:
    r = 11;
    break;
    case 6:
    r = 12;
    break;
    default:
    Serial.print("error.val+=1");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    break;
  }
  switch(y)
  {
    case 0:
    digitalWrite(r, LOW);
    break;
    case 1:
    digitalWrite(r, HIGH);
    break;
    default:
    Serial.print("error.val+=1");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
  }
}

void Digital(int x, int y)
{
  int d;
  switch (x)
  {
    case 1:
    d = 3;
    break;
    case 2:
    d = 5;
    break;
    case 3:
    d = 6;
    break;
    case 4:
    d = 9;
    break;
    case 5:
    d = 10;
    break;
    default:
    Serial.print("error.val+=1");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    break;
  }
  switch (y)
  {
    case 0:
    analogWrite(d, 0);
    break;
    case 1:
    analogWrite(d, 255);
    break;
    default:
    Serial.print("error.val+=1");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    break;
  }
}

int Analog(int x)
{
  int a;
  switch(x)
  {
    case 1:
    a = analogRead(A0);
    break;
    case 2:
    a = analogRead(A1);
    break;
    case 3:
    a = analogRead(A2);
    break;
    case 4:
    a = analogRead(A3);
    break;
    case 5:
    a = analogRead(A6);
    break;
    default:
    a = 0;
    Serial.print("error.val+=1");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    break;
  }
  return a;
}

void PWM(int x, int y)
{
  int d;
  int value;
  switch (x)
  {
    case 1:
    d = 3;
    break;
    case 2:
    d = 5;
    break;
    case 3:
    d = 6;
    break;
    case 4:
    d = 9;
    break;
    case 5:
    d = 10;
    break;
    default:
    Serial.print("error.val+=1");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    break;
  }
  if(y<255)
  {
    analogWrite(d, y);
  }
  else
  {
    Serial.print("error.val+=1");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
  }
}
void ManualData()
{
  int a1value = analogRead(A0);
  Serial.print("va0.val=");
  Serial.print(a1value);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  int a2value = analogRead(A1);
  Serial.print("va1.val=");
  Serial.print(a2value);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  int a3value = analogRead(A2);
  Serial.print("va2.val=");
  Serial.print(a3value);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  int a4value = analogRead(A3);
  Serial.print("va3.val=");
  Serial.print(a4value);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  int a5value = analogRead(A4);
  Serial.print("va4.val=");
  Serial.print(a5value);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  String r1status = "default";
  r1status = digitalRead(2);
  Serial.print("va5.txt=\"");
  Serial.print(r1status);
  Serial.print("\"");
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
    String r2status = "default";
  r2status = digitalRead(4);
  Serial.print("va6.txt=\"");
  Serial.print(r2status);
  Serial.print("\"");
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
      String r3status = "default";
  r3status = digitalRead(7);
  Serial.print("va7.txt=\"");
  Serial.print(r3status);
  Serial.print("\"");
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
      String r4status = "default";
  r4status = digitalRead(8);
  Serial.print("va8.txt=\"");
  Serial.print(r4status);
  Serial.print("\"");
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
      String r5status = "default";
  r5status = digitalRead(11);
  Serial.print("va9.txt=\"");
  Serial.print(r5status);
  Serial.print("\"");
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
      String r6status = "default";
  r6status = digitalRead(12);
  Serial.print("va10.txt=\"");
  Serial.print(r6status);
  Serial.print("\"");
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  int d1value = Dstatus[1];
  Serial.print("va11.val=");
  Serial.print(d1value);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  int d2value = Dstatus[2];
  Serial.print("va12.val=");
  Serial.print(d2value);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  int d3value = Dstatus[3];
  Serial.print("va13.val=");
  Serial.print(d3value);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  int d4value = Dstatus[4];
  Serial.print("va14.val=");
  Serial.print(d4value);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  int d5value = Dstatus[5];
  Serial.print("va15.val=");
  Serial.print(d5value);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
}

void Temperature()
{
  int temperature[3] = {0, 80, 75};
  temperature[0] = analogRead(A7);
if(temperature[0]>temperature[1])
{
  digitalWrite(13, HIGH);
}
else if(temperature[0]<temperature[2])
{
  digitalWrite(13, LOW);
}
  Serial.print("temp.val=");
  Serial.print(temperature[0]);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
}
 
 void GapJunctionSetup()
 {
  GapJunctionBool = true;
Serial.begin(256000);
Serial.setTimeout(100);
pinMode(2, OUTPUT);
pinMode(4, OUTPUT);
pinMode(7, OUTPUT);
pinMode(8, OUTPUT);
pinMode(11, OUTPUT);
pinMode(12, OUTPUT);
pinMode(13, OUTPUT);
pinMode(A0, INPUT);
pinMode(A1, INPUT);
pinMode(A2, INPUT);
pinMode(A3, INPUT);
pinMode(A6, INPUT);
pinMode(A7, INPUT);
analogWrite(3, 0);
analogWrite(5, 0);
analogWrite(6, 0);
analogWrite(9, 0);
analogWrite(10, 0);
digitalWrite(2, 0);
digitalWrite(4, 0);
digitalWrite(7, 0);
digitalWrite(8, 0);
digitalWrite(11, 0);
digitalWrite(12, 0);
while(Serial.availableForWrite()<4) 
{ 
delay(10); 
}
  Serial.print("rest");
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
}

void GapJunctionRun()
{
  do
  {
    
  if(Serial.available()>0) 
{
    


 byteRead[0]=0;
 byteRead[1]=0;
 byteRead[2]=0;
 byteRead[3]=0;
 byteRead[4]=0;
 byteRead[5]=0;
 PressEvent=0;
    
    Serial.readBytes(byteRead, 6);     //Update the byteRead variable with the Hex value received on the Serial COM port.

if(byteRead[0]==relay & byteRead[1]==relay1)
{
  Relay(1, byteRead[2]);
  Rstatus[1] = byteRead[2];
}
if(byteRead[0]==relay & byteRead[1]==relay2)
{
  Relay(2, byteRead[2]);
  Rstatus[2] = byteRead[2];
}
if(byteRead[0]==relay & byteRead[1]==relay3)
{
  Relay(3, byteRead[2]);
  Rstatus[3] = byteRead[2];
}
if(byteRead[0]==relay & byteRead[1]==relay4)
{
  Relay(4, byteRead[2]);
  Rstatus[4] = byteRead[2];
}
if(byteRead[0]==relay & byteRead[1]==relay5)
{
  Relay(5, byteRead[2]);
  Rstatus[5] = byteRead[2];
}
if(byteRead[0]==relay & byteRead[1]==relay6)
{
  Relay(6, byteRead[2]);
  Rstatus[6] = byteRead[2];
}
if(byteRead[0]==digit & byteRead[1]==digit1)
{
  Digital(1, byteRead[2]);
  Dstatus[1] = byteRead[2] * 255;
}
if(byteRead[0]==digit & byteRead[1]==digit2)
{
  Digital(2, byteRead[2]);
  Dstatus[2] = byteRead[2] * 255;
}
if(byteRead[0]==digit & byteRead[1]==digit3)
{
  Digital(3, byteRead[2]);
  Dstatus[3] = byteRead[2] * 255;
}
if(byteRead[0]==digit & byteRead[1]==digit4)
{
  Digital(4, byteRead[2]);
  Dstatus[4] = byteRead[2] * 255;
}
if(byteRead[0]==digit & byteRead[1]==digit5)
{
  Digital(5, byteRead[2]);
  Dstatus[5] = byteRead[2] * 255;
}
if(byteRead[0]==pwm & byteRead[1]==pwm1)
{
  PWM(1, byteRead[2]);
  Dstatus[1] = byteRead[2];
}
if(byteRead[0]==pwm & byteRead[1]==pwm2)
{
  PWM(2, byteRead[2]);
  Dstatus[2] = byteRead[2];
}
if(byteRead[0]==pwm & byteRead[1]==pwm3)
{
  PWM(2, byteRead[2]);
  Dstatus[3] = byteRead[2];
}
if(byteRead[0]==pwm & byteRead[1]==pwm4)
{
  PWM(3, byteRead[2]);
  Dstatus[4] = byteRead[2];
}
if(byteRead[0]==pwm & byteRead[1]==pwm5)
{
  PWM(5, byteRead[2]);
  Dstatus[5] = byteRead[2];
}

if(byteRead[0]==rtcget)
{
  Month = byteRead[1];
  Day = byteRead[2];
  Hour = byteRead[3];
  Minute = byteRead[4];
  Second = byteRead[5];
  Temperature();
}
if(byteRead[0]==pageget & byteRead[1]==manualis)
{
  ManualData();
  GapJunctionBool = true;
}
if(byteRead[0]==pageget & byteRead[1]==automatikus)
{
  GapJunctionBool = false;
  PressEvent = byteRead[2];
}
if(byteRead[0]==pageget & byteRead[1]==fooldal)
{
  GapJunctionBool = true;
}
}
  }while(GapJunctionBool==true);
  
}



int Input(int x)
{
  int a;
  switch(x)
  {
    case 1:
    a = analogRead(A0);
    break;
    case 2:
    a = analogRead(A1);
    break;
    case 3:
    a = analogRead(A2);
    break;
    case 4:
    a = analogRead(A3);
    break;
    case 5:
    a = analogRead(A6);
    break;
    default:
    a = 0;
    Serial.print("error.val+=1");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    break;
  }
  if(a > 200)
  {
    return 1;
  }
  else
  {
    return 0;
  }
}

void Text(int x, String y)
{
  Serial.print("text");
  Serial.print(x);
  Serial.print(".txt=\"");
  Serial.print(y);
  Serial.print("\"");
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
}

void Progresstext(String x)
{
  Serial.print("progresstext.txt\"");
  Serial.print(x);
  Serial.print("\"");
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
}

void ProgressBar(int x)
{
  if(x < 101)
  {
  Serial.print("progress.val=");
  Serial.print(x);
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  }
  else
  {
    Serial.print("Invalid value");
  }
  }

  void ProgramMode(int x, String y)
{
  if(x < 7)
  {
  Serial.print("program");
  Serial.print(x);
  Serial.print(".txt=\"");
  Serial.print(y);
  Serial.print("\"");
  Serial.write(0xff);
  Serial.write(0xff);
  Serial.write(0xff);
  }
  else
  {
    Serial.print("Invalid value");
  }
}

void Memory(String y)
{
  //byte value[1000];
  //switch (x)
  //{
    //case 0:
    //if(Serial.available()>0)
    //{
    //Serial.readBytes(value, 1000);
    //String result = String((char*)value);
	//Serial.println(result);
    //Serial.write(0xff);
    //Serial.write(0xff);
    //Serial.write(0xff);
    //}
    //break;
    //case 1:
    Serial.print("wepo rtcmonth.txt,sys2");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.print("sys2+=2");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.print("wepo rtcday.txt,sys2");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.print("sys2+=2");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.print("wepo rtchour.txt,sys2");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.print("sys2+=2");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.print("wepo rtcminute.txt,sys2");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.print("sys2+=2");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.print("wepo \"");
    Serial.print(y);
    Serial.print("\",sys2");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.print("sys2+=8");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.print("wepo sys2,1000");
    Serial.write(0xff);
    Serial.write(0xff);
    Serial.write(0xff);
    //break;
    //default:
    //Serial.print("error.val+=1");
    //Serial.write(0xff);
    //Serial.write(0xff);
    //Serial.write(0xff);
    //break;
  //}
}